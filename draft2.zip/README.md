# Basic Example of using SDK for EvmTransactions + MetaMask

## How to run?

First put your `Rango-API-KEY` inside `src/App.tsx`. Then run these commands:

```shell
  cd /path/to/examples/metamask-example/
  npm install
  npm start
```
