import React, { useState, useEffect } from "react";
import Dashboard from "../Dashboard/Dashboard";

const Home = () => {
  return (
    <>
      <Dashboard />
    </>
  );
};

export default Home;